package com.h4ll0.survivenight

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private val Red = Color(0xFFE0262E)
private val Bg = Color(0xFF0D0A0A)

data class Survivor(val name: String, val skill: String, val maxStamina: Float, val regen: Float, val killerSpeedMul: Float, val instinct: Boolean)
val SURVIVORS = listOf(
    Survivor("Rani", "Pelari — stamina lebih besar & cepat pulih", 150f, 18f, 1f, false),
    Survivor("Dimas", "Hening — langkahmu lebih senyap, Kelam sedikit melambat", 100f, 14f, 0.9f, false),
    Survivor("Yuda", "Insting — sesekali tau arah Kelam", 100f, 14f, 1f, true),
)

data class Rect2(val x: Float, val y: Float, val w: Float, val h: Float)
const val WORLD_W = 800f
const val WORLD_H = 450f
val OBSTACLES = listOf(
    Rect2(150f, 100f, 90f, 60f), Rect2(500f, 250f, 110f, 70f),
    Rect2(300f, 300f, 70f, 90f), Rect2(620f, 60f, 60f, 100f), Rect2(80f, 280f, 80f, 70f)
)

enum class Screen { SELECT, PLAY, WIN, LOSE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Game() }
            }
        }
    }
}

fun clampToWorld(x: Float, y: Float, r: Float) = x.coerceIn(r, WORLD_W - r) to y.coerceIn(r, WORLD_H - r)

fun hitsObstacle(x: Float, y: Float, r: Float): Boolean = OBSTACLES.any { o ->
    x + r > o.x && x - r < o.x + o.w && y + r > o.y && y - r < o.y + o.h
}

@Composable
fun Game() {
    var screen by remember { mutableStateOf(Screen.SELECT) }
    var survivor by remember { mutableStateOf(SURVIVORS[0]) }

    when (screen) {
        Screen.SELECT -> SelectScreen { survivor = it; screen = Screen.PLAY }
        Screen.PLAY -> PlayScreen(survivor, onWin = { screen = Screen.WIN }, onLose = { screen = Screen.LOSE })
        Screen.WIN -> WinScreen()
        Screen.LOSE -> LoseScreen { screen = Screen.SELECT }
    }
}

@Composable
fun SelectScreen(onPick: (Survivor) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("MALAM BERTAHAN", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Red)
        Text("Bertahan 3 menit dari Kelam. Pilih survivor:", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SURVIVORS.forEach { s ->
                Card(Modifier.weight(1f).clickable { onPick(s) }) {
                    Column(Modifier.padding(10.dp)) {
                        Text(s.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(s.skill, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun WinScreen() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        delay(2200)
        (ctx as? ComponentActivity)?.finishAndRemoveTask()
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("KAMU SELAMAT", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7CFF8C))
        Spacer(Modifier.height(8.dp))
        Text("Menutup aplikasi...", color = Color.Gray)
    }
}

@Composable
fun LoseScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("KAMU TERTANGKAP", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(16.dp))
        Button(onBack) { Text("Main Lagi") }
    }
}

@Composable
fun PlayScreen(survivor: Survivor, onWin: () -> Unit, onLose: () -> Unit) {
    var px by remember { mutableStateOf(100f) }
    var py by remember { mutableStateOf(100f) }
    var kx by remember { mutableStateOf(650f) }
    var ky by remember { mutableStateOf(380f) }
    var stamina by remember { mutableStateOf(survivor.maxStamina) }
    var timeLeft by remember { mutableStateOf(180f) }
    var joyDir by remember { mutableStateOf(Offset.Zero) }
    var sprinting by remember { mutableStateOf(false) }
    var instinctFlash by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        var lastInstinct = -1
        var last = System.currentTimeMillis()
        while (isActive && !ended) {
            delay(16)
            val now = System.currentTimeMillis()
            val dt = ((now - last) / 1000f).coerceAtMost(0.05f)
            last = now

            timeLeft -= dt
            if (timeLeft <= 0f) { ended = true; onWin(); break }

            val dist0 = joyDir.getDistance()
            val wantSprint = sprinting && stamina > 0f && dist0 > 0.1f
            val speed = if (wantSprint) 140f else 70f
            stamina = if (wantSprint) max(0f, stamina - 35f * dt) else min(survivor.maxStamina, stamina + survivor.regen * dt)

            if (dist0 > 0.05f) {
                val nx = joyDir.x / dist0; val ny = joyDir.y / dist0
                val tryX = px + nx * speed * dt
                val tryY = py + ny * speed * dt
                if (!hitsObstacle(tryX, py, 10f)) px = tryX
                if (!hitsObstacle(px, tryY, 10f)) py = tryY
                val c = clampToWorld(px, py, 10f); px = c.first; py = c.second
            }

            val dx = px - kx; val dy = py - ky
            val dist = hypot(dx, dy)
            if (dist > 1f) {
                val kSpeed = 95f * survivor.killerSpeedMul
                val kx2 = kx + (dx / dist) * kSpeed * dt
                val ky2 = ky + (dy / dist) * kSpeed * dt
                if (!hitsObstacle(kx2, ky, 12f)) kx = kx2
                if (!hitsObstacle(kx, ky2, 12f)) ky = ky2
                val c = clampToWorld(kx, ky, 12f); kx = c.first; ky = c.second
            }

            if (dist < 20f) { ended = true; onLose(); break }

            val sec20 = (timeLeft.toInt() / 20)
            if (survivor.instinct && timeLeft.toInt() % 20 == 0 && sec20 != lastInstinct) {
                lastInstinct = sec20
                instinctFlash = true
                delay(3000)
                instinctFlash = false
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { joyDir = Offset.Zero },
                    onDragCancel = { joyDir = Offset.Zero }
                ) { change, drag ->
                    change.consume()
                    val newX = joyDir.x + drag.x * 0.02f
                    val newY = joyDir.y + drag.y * 0.02f
                    val d = hypot(newX, newY)
                    joyDir = if (d > 0f) {
                        val clamped = d.coerceAtMost(1f)
                        Offset(newX / d * clamped, newY / d * clamped)
                    } else Offset.Zero
                }
            }
        ) {
            val sx = size.width / WORLD_W; val sy = size.height / WORLD_H
            drawRect(Bg, size = size)
            OBSTACLES.forEach { o ->
                drawRect(Color(0xFF2A1A1A), topLeft = Offset(o.x * sx, o.y * sy), size = androidx.compose.ui.geometry.Size(o.w * sx, o.h * sy))
            }
            drawCircle(Color(0xFF2E8CFF), radius = 10f * sx, center = Offset(px * sx, py * sy))
            drawCircle(Red, radius = 12f * sx, center = Offset(kx * sx, ky * sy))
            if (instinctFlash) {
                drawLine(Color.Yellow, Offset(px * sx, py * sy), Offset(kx * sx, ky * sy), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }

        Column(Modifier.align(Alignment.TopStart).padding(14.dp)) {
            val m = (timeLeft.toInt() / 60); val s = (timeLeft.toInt() % 60)
            Text("%02d:%02d".format(m, s), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(140.dp).height(10.dp).background(Color(0xFF333333))) {
                Box(Modifier.fillMaxHeight().width(140.dp * (stamina / survivor.maxStamina)).background(Color(0xFF7CFF8C)))
            }
        }

        Button(
            onClick = {},
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { sprinting = true },
                        onDragEnd = { sprinting = false },
                        onDragCancel = { sprinting = false }
                    ) { _, _ -> }
                },
            colors = ButtonDefaults.buttonColors(containerColor = if (sprinting) Color(0xFF7CFF8C) else Red)
        ) { Text("LARI (tahan)") }
    }
}
